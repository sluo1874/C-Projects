//
//  main.c
//  mythread
//
//  Created by luosai on 14-4-17.
//  Copyright (c) 2014年 luosai. All rights reserved.
//

#include <stdio.h>

int main(int argc, const char * argv[])
{

    // insert code here...
    printf("Hello, World!\n");
    return 0;
}

